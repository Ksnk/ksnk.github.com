<?php
/**
 * Reader HTML 2 ML (mediterial language)
 * User: Сергей
 * Date: 12.02.12
 * Time: 22:31
 * To change this template use File | Settings | File Templates.
 */

require_once "MlObject.php";
/**
 * Class to read HTML and build some sort of Recursive array (ML)
 */
class reader_MARKDOWN
{

}
